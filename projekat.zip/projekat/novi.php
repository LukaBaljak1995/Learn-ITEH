<?php
session_start();
if(isset($_SESSION["id"])){
  unset($_SESSION["id"]);
} else {
    unset($_SESSION["id"]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Nauči iteh!</title>

    
    <link rel="icon" type="" href="img/elab-logo.png">

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/style.min.css" rel="stylesheet">

    <!-- Custom Fonts -->


    <link href="fontaw/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link href='https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">

    <link rel="stylesheet" href="jqwidgets/styles/jqx.base.css" type="text/css" />
    <script type="text/javascript" src="scripts/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="jqwidgets/jqxcore.js"></script>
    <script type="text/javascript" src="jqwidgets/jqxpasswordinput.js"></script>
    <script type="text/javascript" src="jqwidgets/jqxtooltip.js"></script>
    <script type="text/javascript" src="scripts/demos.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $("#register_password").jqxPasswordInput({ showStrength: true, showStrengthPosition: "right",
                // The passwordStrength enables you to override the built-in strength calculation.
                passwordStrength: function (password, characters, defaultStrength) {
                    var length = password.length;
                    var letters = characters.letters;
                    var numbers = characters.numbers;
                    var specialKeys = characters.specialKeys;
                    var strengthCoefficient = letters + numbers + 2 * specialKeys + letters * numbers * specialKeys;
                    var strengthValue;
                    if (length < 4) {
                        strengthValue = "Too short";
                    } else if (strengthCoefficient < 10) {
                        strengthValue = "Weak";
                    } else if (strengthCoefficient < 20) {
                        strengthValue = "Fair";
                    } else if (strengthCoefficient < 30) {
                        strengthValue = "Good";
                    } else {
                        strengthValue = "Strong";
                    };
                    return strengthValue;
                },
                // The strengthTypeRenderer enables you to override the built-in rendering of the Strength tooltip.
                strengthTypeRenderer: function (password, characters, defaultStrength) {
                var length = password.length;
                var letters = characters.letters;
                var numbers = characters.numbers;
                var specialKeys = characters.specialKeys;
                var strengthCoefficient = letters + numbers + 2 * specialKeys + letters * numbers / 2 + length;
                var strengthValue;
                var color;
                if (length < 8) {
                    strengthValue = "Too short";
                    color = "rgb(170, 0, 51)";
                } else if (strengthCoefficient < 20) {
                    strengthValue = "Weak";
                    color = "rgb(170, 0, 51)";
                } else if (strengthCoefficient < 30) {
                    strengthValue = "Fair";
                    color = "rgb(255, 204, 51)";
                } else if (strengthCoefficient < 40) {
                    strengthValue = "Good";
                    color = "rgb(45, 152, 243)";
                } else {
                    strengthValue = "Strong";
                    color = "rgb(118, 194, 97)";
                }    ;
                return "<div style=' font-style: italic; font-weight: bold; color: " + color + ";'>" + strengthValue + "</div>";
            }
            });
        });
    </script>
</head>

<body style="background-image: url(img/lines-of-code.jpg) !important; background-color: black;">

<section>
    <div class="container" >
        <div class="row" style="margin-top: 50px;">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-login">
                    <div class="panel-heading"> 
                    
                        <div class="row">
                            <div class="col-xs-6">
                                <a href="#login-form" class="active" id="login-form-link">Uloguj se</a> 
                               
                            </div>
                            <div class="col-xs-6">
                           
                                <a href="#register-form" id="register-form-link">Registracija</a>
                            </div>
                        </div>
                        <hr>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <form id="login-form" method="post" role="form" action="loginobrada.php" style="display: block;">
                                    <div class="form-group">
                                        <input type="text" name="email" id="email" tabindex="1" class="form-control" placeholder="Email" value="" minlength="5" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="password" id="login_password" tabindex="2" class="form-control" placeholder="Šifra" maxlength="16" required>
                                    </div>
                                   
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 col-sm-offset-3">
                                                <input type="submit" name="login-submit" id="login-submit" tabindex="4" class="form-control btn btn-login" value="Log In" data-toggle="modal" data-target="#myModal">
                                               
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                    

                                <form id="register-form"  method="post" action="loginobrada.php" role="form" style="display: none;">
                                    <div class="form-group">
                                        <input type="name" name="name" id="name" tabindex="1" class="form-control" placeholder="Ime" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="surname" name="surname" id="surname" tabindex="1" class="form-control" placeholder="Prezime" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="Email" value="" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="password" id="register_password" tabindex="2" class="form-control" placeholder="Šifra" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="confirm-password" id="confirm-password" tabindex="2" class="form-control" placeholder="Potvrdi šifru" onkeyup="validate_eqity()" required>
                                    </div>

                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 col-sm-offset-3">
                                            <button type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="Register Now" " >Pošalji</button>                                             
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php
                    if(isset($_SESSION["login_pogresan"])){
                        ?>
                            <div><p><b>Pogresan email ili password!</b></p></div>
                        <?php
                        
                        unset($_SESSION["login_pogresan"]);
                    } else {
                        
                    }
                    ?>
                </div>
            </div>

        </div>

    </div>
</section>

    

    <script type="text/javascript">
        
    function validate_eqity(){
        var pass = document.getElementById("register_password").value;
        var c_pass = document.getElementById("confirm-password").value;

        //alert(pass+" "+c_pass)
        if(pass==c_pass){
            document.getElementById("confirm-password").style.background="#80ffd4";
            document.getElementById("confirm-password").style.color="black";
            var content = document.createTextNode("Pasword confirmed!");
            document.getElementById("confirm-password").appendChild(content);
            //document.getElementById("confirm-password")innerHTML += "Pasword confirmed!";
        } else {
            document.getElementById("confirm-password").style.color="red";
            document.getElementById("confirm-password").style.background="white";
        }
    }


    </script>

   <script type="text/javascript">$(function() {

    $('#login-form-link').click(function(e) {
        $("#login-form").delay(100).fadeIn(100);
        $("#register-form").fadeOut(100);
        $('#register-form-link').removeClass('active');
        $(this).addClass('active');
        e.preventDefault();
    });
    $('#register-form-link').click(function(e) {
        $("#register-form").delay(100).fadeIn(100);
        $("#login-form").fadeOut(100);
        $('#login-form-link').removeClass('active');
        $(this).addClass('active');
        e.preventDefault();
    });

});
</script>


</body>

</html>
<?php

?>