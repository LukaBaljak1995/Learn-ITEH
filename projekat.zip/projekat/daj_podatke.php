<?php

$id = $_GET["id"];
include 'Database.php';
$db = new Database("learn_iteh");
session_start();
$db->select("Student","DatumPridruzivanja",null,null,null,"Email = '".$_SESSION['id']."'");
$red = $db->getResult()->fetch_object();
$datumPridruzivanja=$red->DatumPridruzivanja;


switch ($id) {
	case 'brojPredjenihDefinicija':
	//vadjenje ukupnog broja definicija
		$sql = "SELECT count(*) AS ukupanBroj FROM Definicija WHERE DatumDefinicija<'".$datumPridruzivanja."'";
		
		$db->executeQuery($sql);
    	$red = $db->getResult()->fetch_object();
    	$ukupanBroj = $red->ukupanBroj;
    	$sql = "SELECT count(*) AS brojPoznatih FROM PoznavanjeDefinicije where email='".$_SESSION['id']."'";
    	
    	$db->executeQuery($sql);
    	$red = $db->getResult()->fetch_object();
    	$brojPoznatih = $red->brojPoznatih;

    	echo $brojPoznatih."@".$ukupanBroj;
		break;
	case 'brojPredjenihOblastiPoDefinicijama':
		$sql = "SELECT count(*) AS brojPoznatih FROM `PoznavanjeDefinicije` WHERE Email='".$_SESSION["id"]."'";
		
    	$db->executeQuery($sql);
    	$red = $db->getResult()->fetch_object();
    	$brojPoznatih = $red->brojPoznatih;

    	$brojPredjenihOblastiPoDefinicijama=0;
    	$ukupanBroj=0;
    	$i=1;
    	while ( $i<= 6) {
    		$sql = "SELECT count(*) AS ukupanBroj FROM Definicija WHERE TipDefinicijeID = ".$i." AND DatumDefinicija < '" . $datumPridruzivanja."'";
    		
			$db->executeQuery($sql);
	    	$red = $db->getResult()->fetch_object();
	    	//ovo u testnom primeru treba, kad sam za dve grupe radio, a u pravom nece trebati
	    	if($red->ukupanBroj==0){
	    		break;
	    	}
	    	$ukupanBroj += $red->ukupanBroj;
	    	if($brojPoznatih>=$ukupanBroj){
	    		$brojPredjenihOblastiPoDefinicijama++;
	    	} else {
	    		break;
	    	}
	    	$i++;
    	}
    	echo $brojPredjenihOblastiPoDefinicijama;
    	break;
	case 'brojPredjenihPitanja':
		//broj tacno odgovorenih pitanja
		$sql = "SELECT COUNT(*) AS brojPredjenihPitanja FROM Odgovor WHERE Email='".$_SESSION["id"]."' AND OCENA = 1 ";
		
		$db->executeQuery($sql);
    	$red = $db->getResult()->fetch_object();
    	$brojPredjenihPitanja = $red->brojPredjenihPitanja;
    	//ukupan broj pitanja
    	$sql = "SELECT COUNT(*) AS ukupanBroj FROM Pitanje WHERE DatumPitanje < '".$datumPridruzivanja."'";
    	
		$db->executeQuery($sql);
    	$red = $db->getResult()->fetch_object();
    	$ukupanBroj = $red->ukupanBroj;

    	echo $brojPredjenihPitanja."@".$ukupanBroj;



	break;
	case 'brojPredjenihOblastiPoPitanjima':
		//broj tacno odgovorenih pitanja
		$sql = "SELECT COUNT(*) AS brojPredjenihPitanja FROM Odgovor WHERE Email='".$_SESSION["id"]."' AND OCENA = 1";
		
		$db->executeQuery($sql);
    	$red = $db->getResult()->fetch_object();
    	$brojPredjenihPitanja = $red->brojPredjenihPitanja;

    	$brojPredjenihOblastiPoPitanjima=0;
    	$ukupanBroj=0;
    	$i=1;
    	while ( $i<= 6) {
	    	//broj pitanja u odredjenoj oblasti
			$sql = "SELECT COUNT(*) as ukupanBroj  FROM Pitanje JOIN Definicija ON Pitanje.DefinicijaID=Definicija.DefinicijaID 
			JOIN TipDefinicije on Definicija.TipDefinicijeID=TipDefinicije.TipDefinicijeID
			WHERE TipDefinicije.TipDefinicijeID=".$i." AND Pitanje.DatumPitanje < '".$datumPridruzivanja."'";
			
			$db->executeQuery($sql);
    	$red = $db->getResult()->fetch_object();
			//ovo u testnom primeru treba, kad sam za dve grupe radio, a u pravom nece trebati
	    	if($red->ukupanBroj==0){
	    		break;
	    	}
	    	$ukupanBroj += $red->ukupanBroj;
	    	if($brojPredjenihPitanja>=$ukupanBroj){
	    		$brojPredjenihOblastiPoPitanjima++;
	    	} else {
	    		break;
	    	}
	    	$i++;
    	}

    	echo $brojPredjenihOblastiPoPitanjima;
	break;
	default:
		echo "Greska";
		break;
}

?>