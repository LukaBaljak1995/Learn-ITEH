<?php
	include 'Database.php';
	$db = new Database("learn_iteh");
	session_start();
	$tipDefinicije = $_GET["tipDefinicije"];
	$db -> select("PoznavanjeDefinicije", "Definicija.TekstDefinicije", "Definicija","DefinicijaID","DefinicijaID", "Definicija.TipDefinicijeID = " .$tipDefinicije." AND PoznavanjeDefinicije.Email = '".$_SESSION["id"]."'");
	if($db->getRecords()==0){
		echo "Niste još prešli niti jednu definiciju iz ove oblasti!";
	} else {
		?>
		<table class="table table-bordered">
		  <thead class="thead-light">
		    <tr>
		      <th scope="col" style="width:120px;text-align: center;">Redni broj</th>
		      <th scope="col" style="text-align: center;">Tekst definicije</th>
		    </tr>
		  </thead>
		  <tbody>
		<?php
		$i=1;
		while($red=$db->getResult()->fetch_object()){
			?>
				<tr>	
					<th scope="row" style="text-align: center;"> <?php echo $i."."; ?></th>
					<td> <?php echo $red->TekstDefinicije; ?> </td>
				</tr>
			<?php
			$i++;
		}
	}
	?>

	  </tbody>
	</table>
	<?php


?>
