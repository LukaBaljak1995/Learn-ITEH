<?php
if (isset($_POST['tekstdefinicije']) && isset($_POST['emaildefinicija']) && isset($_POST['tipdefinicijeid'])){
	$tekstdefinicije = $_POST['tekstdefinicije'];
	$emaildefinicija = $_POST['emaildefinicija'];
	$tipdefinicijeid = $_POST['tipdefinicijeid'];
	
	
	include "Database.php";
	$db = new Database("learn_iteh");
	
	//$sql = "INSERT INTO definicija (TekstDefinicije, EmailDefinicija, TipDefinicijeID, DatumDefinicija)
	//VALUES ( '".$tekstdefinicije."', '".$emaildefinicija."','".$tipdefinicijeid."', now() )";
	//$db->executeQuery($sql);
	
	$stmt = $db->prepare("INSERT INTO definicija (TekstDefinicije, EmailDefinicija, TipDefinicijeID, DatumDefinicija) VALUES (?, ?, ?, now() )");
	
	$stmt->bind_param("ssi", $tekstdefinicije, $emaildefinicija, $tipdefinicijeid);
	
	$stmt->execute();
	
	if (!$stmt) {
		echo "Greška pri izvođenju upita!";
	}else{
		if($stmt->affected_rows()==-1){
			printf("\nGreška: %s", $stmt->error);
		}
	}
}else{
	echo "Nisu prosleđeni svi parametri!";
}
?>