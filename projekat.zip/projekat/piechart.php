
<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript" src="jquery-1.10.2.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        //var brojPoznatih, brojNepoznatih=1, odgovor;

        $.get("daj_podatke.php", { id:"brojPredjenihDefinicija" },
                 function(data){
                    var odgovor=data.split("@");
                    var brojPoznatih=parseInt(odgovor[0]);
                    var brojNepoznatih=parseInt(odgovor[1])-brojPoznatih;
                    var datatable = google.visualization.arrayToDataTable([
                      ['Task', 'Hours per Day'],
                      ['Naučene definicije', brojPoznatih],
                      ['Nove definicije',  brojNepoznatih]
                    ]);

                    var options = {
                        title: 'Naučene definicije',
                        legend: 'none',
                        pieHole: 0.4,

                    };

                
                  var chart = new google.visualization.PieChart(document.getElementById('definicije'));
                  chart.draw(datatable, options);
                
               });
      
       $.get("daj_podatke.php", { id:"brojPredjenihOblastiPoDefinicijama" },
             function(data){
              var brojPredjenihOblastiPoDefinicijama = parseInt(data);
              var brojNeredjenihOblastiPoDefinicijama = 6 - brojPredjenihOblastiPoDefinicijama;
             

              var datatable = google.visualization.arrayToDataTable([
                ['Task', 'Hours per Day'],
                ['Pređene oblasti', brojPredjenihOblastiPoDefinicijama],
                ['Nove oblasti',  brojNeredjenihOblastiPoDefinicijama]
              ]);

              var options = {
                title: 'Pređene oblasti po definicijama',
                legend: 'none',
                pieHole: 0.4,

              };
              //iscrtavanje grafika
              var brojPredjenihOblastiPoDefinicijama = new google.visualization.PieChart(document.getElementById('oblastiDefinicije'));
              brojPredjenihOblastiPoDefinicijama.draw(datatable, options);
           });

       $.get("daj_podatke.php", { id:"brojPredjenihPitanja" },
                 function(data){
                    var odgovor=data.split("@");
                    var brojPredjenihPitanja=parseInt(odgovor[0]);
                    var brojNepredjenihPitanja=parseInt(odgovor[1])-brojPredjenihPitanja;
                    var datatable = google.visualization.arrayToDataTable([
                      ['Task', 'Hours per Day'],
                      ['Pređena pitanja', brojPredjenihPitanja],
                      ['Nepređena pitanja',  brojNepredjenihPitanja]
                    ]);

                    var options = {
                        title: 'Pređena pitanja',
                        legend: 'none',
                        pieHole: 0.4,

                    };
                    
                
                  var chart = new google.visualization.PieChart(document.getElementById('pitanja'));
                  chart.draw(datatable, options);
                
               });

       $.get("daj_podatke.php", { id:"brojPredjenihOblastiPoPitanjima" },
        function(data){
          
                var brojPredjenihOblastiPoPitanjima = parseInt(data);
                var brojNepredjenihOblastiPoPitanjima = 6- brojPredjenihOblastiPoPitanjima;

                var datatable = google.visualization.arrayToDataTable([
                ['Task', 'Hours per Day'],
                ['Pređene oblasti', brojPredjenihOblastiPoPitanjima],
                ['Nove oblasti',  brojNepredjenihOblastiPoPitanjima]
              ]);

              var options = {
                title: 'Pređene oblasti po pitanjima',
                legend: 'none',
                pieHole: 0.4,
              };

              var brojPredjenihOblastiPoPitanjima = new google.visualization.PieChart(document.getElementById('oblastiPitanja'));
              brojPredjenihOblastiPoPitanjima.draw(datatable, options);

        });

      }



    </script>
  </head>
  <body>

     <div id = "rezultat"></div>
    <div class="row" style="height: 300px; width:800px">
      <div class="col" id="definicije"></div>
      <div class="col" id="oblastiDefinicije"></div>
    </div>

    <div class="row" style="height: 300px; width:800px">
      <div class="col" id="pitanja"></div>
      <div class="col" id="oblastiPitanja"></div>
    </div>
   


   
  </body>
</html>