<?php
include_once 'Database.php';
$db = new Database("learn_iteh");
$db2 = new Database("learn_iteh");
session_start();
if(isset($_SESSION["id"])){
} else {
  header("novi.php");
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="pocetna_css.css">
    
    <!-- DATATABLES -->
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.css">

    <title>Admin panel</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
		<a class="navbar-brand" href="#">Navbar w/ text</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>

		
		<div class="collapse navbar-collapse" id="navbarNavDropdown">
			<ul class="navbar-nav">
			  <li class="nav-item active">
				
			  </li>
			  <li class="nav-item dropdown" style="margin-left:  1100px;" >
				<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style=" color: black;">
					<?php echo $_SESSION["imeprezime"]; ?>
				</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
				  <a class="dropdown-item" href="novi.php">Odjavi se</a>
				</div>
			  </li>
			</ul>
		 </div>
	</nav>



<div class="sidenav">
	<a href="adminpocetna.php">Početna</a>
	<a href="adminpocetna.php?prikaz=definicija" style="margin-top: 100px">Moje definicije</a>
	<a href="adminpocetna.php?prikaz=pitanje">Moja pitanja</a>
</div>


<div class="container">
    <div class="row" style="margin-top: 50px">

        <div class="col" >
            <?php
            if (isset($_GET["prikaz"])){
                $prikaz = $_GET["prikaz"];
            } else {
                $prikaz = "pocetna";
            }
            switch($prikaz){
                case "pocetna":
                {
                    $sql="SELECT t.tipdefinicijeid, t.naziv, d.tekstdefinicije, d.emaildefinicija, p.tekstpitanja, p.emailpitanje
                    FROM TipDefinicije t JOIN Definicija d ON t.TipDefinicijeID=d.TipDefinicijeID
                    LEFT JOIN Pitanje p ON d.DefinicijaID=p.DefinicijaID
					ORDER BY  t.tipdefinicijeid";
                    
                    $db->executeQuery($sql);
                    
                        if(!$db){ //returns FALSE on failure
                            echo "<br>Nastala je greška pri izvođenju upita!";
                            exit();
                        }
                        if($db->getResult()->num_rows==0){
                            echo "<br>Nema zapisa.";
                        }else{
                            ?>
                            <table id="datatabela">
                                <thead>
                                    <tr>
										<th>TipDefinicijeID</th>
                                        <th>TipDefinicije</th>
                                        <th>TekstDefinicije</th>
                                        <th>TekstPitanja</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    while($red = $db->getResult()->fetch_object()){
                                        ?>
                                        <tr> 
											<td><?php echo $red->tipdefinicijeid; ?> </td>
                                            <td><?php echo $red->naziv; ?> </td>
                                            <td><?php echo $red->tekstdefinicije; ?> </td>
                                            <td><?php echo $red->tekstpitanja; ?> </td>
                                        </tr>
                                        
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                            
                            <br><br>
                            <?php
                            $db->close();
                        }
                    }
                    break;
                    case "definicija":
                    {
						?>
                        
						<button type="submit" id="popupforma" onclick="div_show()">Unesi novu definiciju</button>
						<br><br>
						
						<div id="abc">
							<div id="popupforma" class="form-style-6">
								<span id="popupBoxClose">&times;</span>
								<h1>Unos nove definicije</h1>
								
								<form id="formdefinicija" name="formdefinicija" >
									Tekst definicije: <textarea id="tekstdefinicije"></textarea><br>
									Tip definicije:
									<select name="selecttipdefinicije" id="selecttipdefinicije">
										<?php
										$sql2 = "SELECT * FROM TipDefinicije";
										$db2->executeQuery($sql2);
										if(!$db2){
										 ?>
											<option value="" selected disabled hidden> Nastala je greska pri izvođenju upita! </option>
										 <?php
										}else{
											?> <option id="x" value="" selected disabled hidden>Odaberite tip definicije</option>
											<?php
											while($red2 = $db2->getResult()->fetch_object()){
											?>
												<option id='<?php echo $red2->TipDefinicijeID; ?>' value='<?php echo $red2->TipDefinicijeID; ?>'> <?php echo $red2->Naziv; ?> </option>
											<?php
											}
										}
											?>
									</select>
									<input type="hidden" id="emaildefinicija" name="emaildefinicija" value="<?php echo $_SESSION["id"]; ?>"/>
									<input id="submitdefinicija" onclick="funkcijaDefinicija()" type="button" value="Unesi definiciju"/>
								</form>
							</div>
						</div>


                        <?php
                        
                        //salje se mejl onome ko je loginovan
                        $mailto=$_SESSION["id"];
						$tekstmejla="";
                        
                        $sql="SELECT d.DefinicijaID, d.TekstDefinicije, t.TipDefinicijeID, t.Naziv
                        FROM definicija d RIGHT JOIN tipdefinicije t ON d.TipDefinicijeID=t.TipDefinicijeID
                        WHERE d.EmailDefinicija='$mailto'";
                        $db->executeQuery($sql);
                        
                        ?>
						
                        <table id="datatabela" >
                            <thead>
                                <tr>
                                    <th>DefinicijaID</th>
                                    <th>TekstDefinicije</th>
                                    <th>TipDefinicije</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
								<?php
								
								if(!$db){ //returns FALSE on failure
									echo "<br>Nastala je greška pri izvođenju upita!";
									exit();
								}
								if($db->getResult()->num_rows==0){
									$tekstmejla = "Administrator nema ni jednu unetu definiciju.";
										?></tbody>
										</table><?php
								}else{
								
									while($red = $db->getResult()->fetch_object()){
										?>
										<tr> 
											<td><?php echo $red->DefinicijaID; ?> </td>
											<td>
												<div class='edit'> <?php echo $red->TekstDefinicije; ?> </div> 
												<input type='text' class='txtedit' value='<?php echo $red->TekstDefinicije; ?>' id='TekstDefinicije_<?php echo $red->DefinicijaID; ?>'>
											</td>
											
											<td>
												<!-- u id select-a cuvamo naziv polja koje menjamo i id definicije cije polje menjamo -->
												<select name="tipdefinicije" id="TipDefinicijeID_<?php echo $red->DefinicijaID; ?>">
													<?php
													$sql2 = "SELECT * FROM TipDefinicije";
													$db2->executeQuery($sql2);
													if(!$db2){
														?>
														<option value="" selected disabled hidden> Nastala je greska pri izvođenju upita! </option>
														<?php
													}else{
														?> <option value="" selected disabled hidden> <?php echo $red->Naziv; ?> </option>
														<?php
														while($red2 = $db2->getResult()->fetch_object()){
															?>
															
															<option id='<?php echo $red2->DefinicijaID; ?>' value='<?php echo $red2->TipDefinicijeID; ?>'> <?php echo $red2->Naziv; ?> </option>
															<?php
														}
													}
													?>
												</select>
											</td>   
											<td><button class="deletedefinicija" id="<?php echo $red->DefinicijaID; ?>">Brisanje</button> </td>
										</tr>
										<?php
										$tekstmejla .= $red->TekstDefinicije . "\n\n";
									}
							?>
							</tbody>
						</table>
										<br><br>
										<?php
										$db->close();
									}
						
				?>
				<form method="POST" action=''>
                    <input type="submit" name="button1" value="Pošalji definicije na mejl">
                </form>
				<br><br>

				<?php
                
                
                if (isset($_POST['button1'])) {
                    $url = 'https://api.sendgrid.com/';
                    $user = 'anjab';
                    $pass = 'mojasifra1';
                    
                    $params = array(
                      'api_user' => $user,
                      'api_key' => $pass,
                      'to' => $mailto,
                      'subject' => 'Definicije',
                      'html' => '',
                      'text' => $tekstmejla,
                      'from' => 'anjaxbasara@gmail.com',
                      );

                    $request = $url.'api/mail.send.json';

                                 // Generate curl request
                    $session = curl_init($request);

                                 // Tell curl to use HTTP POST
                    curl_setopt ($session, CURLOPT_POST, true);

                                 // Tell curl that this is the body of the POST
                    curl_setopt ($session, CURLOPT_POSTFIELDS, $params);

                                 // Tell curl not to return headers, but do return the response
                    curl_setopt($session, CURLOPT_HEADER, false);
                    curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                                 // obtain response
                    $response = curl_exec($session);
                    curl_close($session);

                                 // print everything out
                                 //print_r($response);
                    
                    $json_objekat = json_decode($response);
                    if($json_objekat->message == 'success'){
                       echo '<script type="text/javascript">alert("Poslat mejl!");</script>';
                    }else{
						echo '<script type="text/javascript">alert("Nastala je greška pri slanju mejla!");</script>';
					}
               }
           }
           break;
           case "pitanje":
           {
			   ?>
			 <button type="submit" id="popupforma" onclick="div_show()">Unesi novo pitanje</button>
						<br><br>
						
						<div id="abc">
							<div id="popupforma" class="form-style-6">
								<span id="popupBoxClose">&times;</span>
								<h1>Unos novog pitanja</h1>
								
								<form id="formpitanje" name="formpitanje" >
									Tekst pitanja: <textarea id="tekstpitanja"></textarea><br>
									Ponuđeni odgovori: <input type="text" id="ponudjeniodgovori"/> <br>
									Tačan odgovor: <input type="text" id="tacanodgovor"/> <br>
									Definicija čije je ovo pitanje:
									<select name="selectdefinicija" id="selectdefinicija">
										<?php
										$sql2 = "SELECT * FROM Definicija";
										$db2->executeQuery($sql2);
										if(!$db2){
										 ?>
											<option value="" selected disabled hidden> Nastala je greska pri izvođenju upita! </option>
										 <?php
										}else{
											?> <option id="y" value="" selected disabled hidden>Odaberite definiciju</option>
											<?php
											while($red2 = $db2->getResult()->fetch_object()){
											?>
												<option id='<?php echo $red2->DefinicijaID; ?>' value='<?php echo $red2->DefinicijaID; ?>'> <?php echo $red2->TekstDefinicije; ?> </option>
											<?php
											}
										}
											?>
									</select>
									<input type="hidden" id="emailpitanje" name="emailpitanje" value="<?php echo $_SESSION["id"]; ?>"/>
									<input id="submitpitanje" onclick="funkcijaPitanje()" type="button" value="Unesi pitanje"/>
								</form>
							</div>
						</div>
			   <?php   
			   
            $autorpitanja=$_SESSION["id"];
			$tekstmejla="";
			
            $sql="SELECT p.PitanjeID, p.TekstPitanja, p.PonudjeniOdgovori, p.TacanOdgovor, d.TekstDefinicije
            FROM pitanje p JOIN definicija d ON p.DefinicijaID=d.DefinicijaID
            WHERE EmailPitanje='$autorpitanja'";
            $db->executeQuery($sql);
            ?>
            <table id="datatabela">
                <thead>
                    <tr>
                        <th>PitanjeID</th>
                        <th>TekstPitanja</th>
                        <th>PonuđeniOdgovori</th>
                        <th>TačanOdgovor</th>
                        <th>TekstDefinicije</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    
                    if(!$db){
                        echo "<br>Nastala je greška pri izvođenju upita!";
                        exit();
                    }
					if($db->getResult()->num_rows==0){
									$tekstmejla = "Administrator nema ni jedno uneto pitanje.";
										?></tbody>
										</table><?php
					
                    }else{
                        
                        while($red = $db->getResult()->fetch_object()){
                            ?>
                            <tr> 
                                <td><?php echo $red->PitanjeID; ?> </td>
                                <td>
                                    <div class='edit' > <?php echo $red->TekstPitanja; ?></div> 
                                    <input type='text' class='txtedit' value='<?php echo $red->TekstPitanja; ?>' id='TekstPitanja_<?php echo $red->PitanjeID; ?>' >
                                </td>
                                <td>
                                    <div id="ponudj_<?php echo $red->PitanjeID; ?>" class='edit'> <?php echo $red->PonudjeniOdgovori; ?></div> 
                                    <input type='text' class='txtedit' value='<?php echo $red->PonudjeniOdgovori; ?>' id='PonudjeniOdgovori_<?php echo $red->PitanjeID; ?>' >
                                </td>
                                <td>
                                    <div id="tac_<?php echo $red->PitanjeID; ?>" class='edit'> <?php echo $red->TacanOdgovor; ?></div> 
                                    <input type='text' class='txtedit' value='<?php echo $red->TacanOdgovor; ?>' id='TacanOdgovor_<?php echo $red->PitanjeID; ?>' >
                                </td>
                                
                                <!-- u id select-a cuvamo naziv polja koje ce se menjati i id pitanja cije polje menjamo -->
                                <td>
                                    <select name="tekstdefinicije" id="DefinicijaID_<?php echo $red->PitanjeID; ?>" style="width:200px;">
                                        <?php
                                        $sql2 = "SELECT * FROM Definicija";
                                        $db2->executeQuery($sql2);
                                        if(!$db2){
                                            ?>
                                            <option value="" selected disabled hidden> Nastala je greska pri izvođenju upita! </option>
                                            <?php
                                        }else{
                                            ?> <option value="" selected disabled hidden> <?php echo $red->TekstDefinicije; ?> </option>
                                            <?php
                                            while($red2 = $db2->getResult()->fetch_object()){
                                                ?>
                                                <option value='<?php echo $red2->DefinicijaID; ?>'> <?php echo $red2->TekstDefinicije; ?> </option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </td>
                                
                                <td><button class="deletepitanje" id="<?php echo $red->PitanjeID; ?>">Brisanje</button> </td>
                            </tr>
                            
                            <?php
							$tekstmejla .= $red->TekstPitanja . "\n\n";
                        }
                        ?>
                    </tbody>
                </table>
                
                <br><br>
                <?php
                $db->close();
            }
			?>
			<form method="POST" action=''>
                    <input type="submit" name="button2" value="Pošalji pitanja na mejl">
            </form>
			<br><br>
				

				<?php
                
                
                if (isset($_POST['button2'])) {
                    $url = 'https://api.sendgrid.com/';
                    $user = 'anjab';
                    $pass = 'mojasifra1';
                    
                    $params = array(
                      'api_user' => $user,
                      'api_key' => $pass,
                      'to' => $autorpitanja,
                      'subject' => 'Pitanja',
                      'html' => '',
                      'text' => $tekstmejla,
                      'from' => 'anjaxbasara@gmail.com',
                      );

                    $request = $url.'api/mail.send.json';

                                 // Generate curl request
                    $session = curl_init($request);

                                 // Tell curl to use HTTP POST
                    curl_setopt ($session, CURLOPT_POST, true);

                                 // Tell curl that this is the body of the POST
                    curl_setopt ($session, CURLOPT_POSTFIELDS, $params);

                                 // Tell curl not to return headers, but do return the response
                    curl_setopt($session, CURLOPT_HEADER, false);
                    curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                                 // obtain response
                    $response = curl_exec($session);
                    curl_close($session);

                                 // print everything out
                                 //print_r($response);
                    
                    $json_objekat = json_decode($response);
                    if($json_objekat->message == 'success'){
                       echo '<script type="text/javascript">alert("Poslat mejl!");</script>';
                    }else{
						echo '<script type="text/javascript">alert("Nastala je greška pri slanju mejla!");</script>';
					}
				}
        }
        break;
        default:
        echo "<br>Greska 404: Stranica nije pronađena!<br>";
        break;
    }
    ?>
    
    
</div>
<div class="col-12 col-md-auto">
  
</div>
<div class="col col-lg-2">
  
</div>
</div>
</div>




<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script type="text/javascript" src="jquery-1.10.2.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


<!-- DATATABLES -->
<script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.js"></script>

<script>
$(function(){
    $("#datatabela").dataTable();
})
</script>

<script>
$(document).ready(function() {
    var table = $('#datatabela').DataTable();
	
	$('#datatabela tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
    
    $('.deletepitanje').click( function () {
        var id = $(this).attr('id');
        
        $.ajax({
            type: 'POST',
            url: 'deletepitanje.php',
            dataType:'text',
            data:{id:id},
            success : function(data){
                  //delete the row
                  table.row('.selected').remove().draw( false );
              },
              error: function(xhr){
                 alert(id);
             }}); 

    } );
    
    $('.deletedefinicija').click( function () {
        var id = $(this).attr('id');
        
        $.ajax({
            type: 'POST',
            url: 'deletedefinicija.php',
            dataType:'text',
            data:{id:id},
            success : function(data){
                  //delete the row
                  table.row('.selected').remove().draw( false );
              },
              error: function(xhr){
                 alert(id);
             }}); 

    } );
    
    
    
} );
</script>

<!-- live update na formi, text polja -->
<script>
$(document).ready(function(){
    
            // Show Input element
            $('.edit').click(function(){
              $('.txtedit').hide();
              $(this).next('.txtedit').show().focus();
              $(this).hide();
			});

             // Save data
             $(".txtedit").focusout(function(){
              var id = this.id;
              var split_id = id.split("_");
              var field_name = split_id[0];
              var edit_id = split_id[1];
              var value = $(this).val();

              // Hide Input element
              $(this).hide();

              // Hide and Change Text of the container with input element
              $(this).prev('.edit').show();
              $(this).prev('.edit').text(value);
              
              // Sending AJAX request
              if( value != ''){
                  
                if(field_name=='TekstDefinicije'){
                  
                  $.ajax({
                     url: 'updatedefinicija.php',
                     type: 'post',
                     data: { field:field_name, value:value, id:edit_id },
                     success:function(response){
                        console.log('Save successfully'); 
                    }
                });
              }
              
              if(field_name=='TekstPitanja'){
                  
                  $.ajax({
                     url: 'updatepitanje.php',
                     type: 'post',
                     data: { field:field_name, value:value, id:edit_id },
                     success:function(response){
                        console.log('Save successfully'); 
                    }
                });
              }
              
              if(field_name=='PonudjeniOdgovori'){
                    //dobijemo ceo id div-a
                    var idd="tac_";
                    var tacd=idd.concat(edit_id);
                    
                    //uzimamo text iz tog div-a (tacan odgovor)
                    var tacdiv = document.getElementById(tacd);
                    var tacanodgovor = tacdiv.textContent.trim();
                    
                    //split-ujemo na osnovu @ u niz
                    var ponudjniz = value.split("@");
                    
                    //regularan izraz da ne sme da se zavrsava na @ i da ne sme da pocinje na @
                    var zavrsava = value.match(/.*@$/);
                    var pocinje = value.match(/^@.*/);
                    
                    
                    if(pocinje!=null || zavrsava!=null || (pocinje!=null && zavrsava!=null)){
                        alert("Polje mora biti u formatu ___@___@___, gde @ razdvaja ponuđene odgovore i ne sme biti ni na početku ni na kraju!");
                    }else if(!ponudjniz.includes(tacanodgovor)){
                        alert("Jedan od ponuđenih odgovara mora biti tačan odgovor!");
                    }else{
                      $.ajax({
                         url: 'updatepitanje.php',
                         type: 'post',
                         data: { field:field_name, value:value, id:edit_id },
                         success:function(response){
                            console.log('Save successfully'); 
                        }
                    });
                  }
              }
              
              if(field_name=='TacanOdgovor'){
                    //dobijemo ceo id div-a
                    var idd="ponudj_";
                    var ponudjd=idd.concat(edit_id);
                    
                    //uzimamo text iz tog div-a (ponudjeni odgovori)
                    var ponudjdiv = document.getElementById(ponudjd);
                    var ponudj = ponudjdiv.textContent.trim();
                    
                    //split-ujemo na osnovu @ u niz
                    var ponudjniz = ponudj.split("@");
                    
                    if( !ponudjniz.includes(value) || value.match(/@/)!=null ){
                        alert("Tačan odgovor mora biti među ponuđenim i ne sme sadržati znak @ !");
                    }else{
                      $.ajax({
                         url: 'updatepitanje.php',
                         type: 'post',
                         data: { field:field_name, value:value, id:edit_id },
                         success:function(response){
                            console.log('Save successfully'); 
                        }
                    });
                  }
              }
          }else{
            alert("Polje ne sme biti prazno!");
        }
        
    });

});
</script>


<!-- live update na formi, dropdown -->
<script>
$(document).ready(function(){
    $("select").on('change', function() {
        
        var id = this.id;
        var split_id = id.split("_");
        var field_name = split_id[0];
        var edit_id = split_id[1];
        var value = $(this).val();
        
        if(field_name=='TipDefinicijeID'){
            $.ajax({
                url: 'updatedefinicija.php',
                type: 'post',
                data: { field:field_name, value:value, id:edit_id },
                success:function(response){
                    console.log('Save successfully'); 
                }
            });
        }
        
        if(field_name=='DefinicijaID'){
            $.ajax({
                url: 'updatepitanje.php',
                type: 'post',
                data: { field:field_name, value:value, id:edit_id },
                success:function(response){
                    console.log('Save successfully'); 
                }
            });
        }
        
        
    });
});
</script>


<!-- unos definicije -->
<script>
	function funkcijaDefinicija() {
		
		var tekstdefinicije = document.getElementById("tekstdefinicije").value;
		var emaildefinicija = document.getElementById("emaildefinicija").value;
		var tipdefinicijeid = $("#selecttipdefinicije option:selected").attr("id");
		
		if (tekstdefinicije == '' || tipdefinicijeid == 'x') {
			alert("Molimo popunite sva polja.");
		} else {
			// AJAX code to submit form.
			$.ajax({
				type: "POST",
				url: "insertdefinicija.php",
				data: { tekstdefinicije:tekstdefinicije, emaildefinicija:emaildefinicija , tipdefinicijeid:tipdefinicijeid },
				success: function(html) {
					$("#abc").fadeOut();
					window.location.reload();
				}
			});
		}
		return false;
	}
</script>
	
<script>
	//funkcija za prikaz popup forme
	function div_show() {
		document.getElementById('abc').style.display = "block";
	}

	//kad se klikne x da nestane forma
	$(function(){
		$("#popupBoxClose").on("click", function(){
			$("#abc").fadeOut();
			
		});
	});	
</script>

<!-- unos pitanja -->
<script>
	function funkcijaPitanje() {
		
		var tekstpitanja = document.getElementById("tekstpitanja").value;
		var ponudjeniodgovori = document.getElementById("ponudjeniodgovori").value;
		var tacanodgovor = document.getElementById("tacanodgovor").value;
		var definicijaid = $("#selectdefinicija option:selected").attr("id");
		var emailpitanje = document.getElementById("emailpitanje").value;
		
		if (tekstpitanja == '' || ponudjeniodgovori == '' || tacanodgovor == '' ||  definicijaid == 'y') {
			alert("Molimo popunite sva polja.");
		} else {
					//split-ujemo na osnovu @ u niz
                    var ponudjniz = ponudjeniodgovori.split("@");
                    
                    //regularan izraz da ne sme da se zavrsava na @ i da ne sme da pocinje na @
                    var zavrsava = ponudjeniodgovori.match(/.*@$/);
                    var pocinje = ponudjeniodgovori.match(/^@.*/);
                    
                    
                    if(pocinje!=null || zavrsava!=null || (pocinje!=null && zavrsava!=null)){
                        alert("Polje mora biti u formatu ___@___@___, gde @ razdvaja ponuđene odgovore i ne sme biti ni na početku ni na kraju!");
                    }else if(  tacanodgovor.match(/@/)!=null ){
                        alert("Tačan odgovor ne sme sadržati znak @ !");
					}else if(!ponudjniz.includes(tacanodgovor) || tacanodgovor.match(/@/)!=null ){
                        alert("Tačan odgovor mora biti među ponuđenim!");
					}else{
			
			
						// AJAX code to submit form.
						$.ajax({
							type: "POST",
							url: "insertpitanje.php",
							data: { tekstpitanja:tekstpitanja, ponudjeniodgovori:ponudjeniodgovori, tacanodgovor:tacanodgovor, definicijaid:definicijaid, emailpitanje:emailpitanje },
							success: function(html) {
								$("#abc").fadeOut();
								window.location.reload();
							}
						});
					}
		}
		return false;
	}
</script>



</body>
</html>
