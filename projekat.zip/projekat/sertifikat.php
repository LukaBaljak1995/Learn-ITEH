<?php 
//podesava se Mime Type pogodan za PDF format
header('Content-Type: application/pdf');
include 'Database.php';
$db = new Database("learn_iteh");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv='Content-Type' content='Type=text/html; charset=utf-8'>
<title>Primer</title>
</head>
<body>
<?php
session_start();
//$rezultat = $_GET["rezultat"];
$db->select("Student","*",null,null,null,"Email = '" . $_SESSION['id']."'");
$red=$db->getResult()->fetch_object();
// '.$red->RezultatTesta.'
//'.$red->ime . ' ' . $red->prezime.'

$tekst = '<div style="width:800px; height:600px; padding:20px; text-align:center; border: 10px solid #787878">
<div style="width:750px; height:550px; padding:20px; text-align:center; border: 5px solid #787878">
       <span style="font-size:50px; font-weight:bold">Sertifikat o poznavanju ITEHa</span>
       <br><br>
       <span style="font-size:25px"><i>Služi kao potvrda da je</i></span>
       <br><br>
       <span style="font-size:30px"><b>'.$red->ime . ' ' . $red->prezime.'</b></span><br/><br/>
       <span style="font-size:25px"><i>uspešno završio/la kurs</i></span> <br/><br/>
       <span style="font-size:30px"><b>Nauči iteh </b></span> <br/><br/>
       <span style="font-size:20px">sa učinkom od <b>'.$red->RezultatTesta.'%</b></span> <br/><br/><br/><br/>
       <span style="font-size:25px"><i>dana</i></span><br>
      <span style="font-size:30px">'.(date("d")).'.'.(date("m")).'.'.(date("Y")).'.</span>
</div>
</div>';

//putanja do PDFCrowd REST API endpoint-a
$url = 'http://pdfcrowd.com/api/pdf/convert/html/';
//iniciranje HTTP CURL zahteva
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//za FON-ovu mrezu treba podesiti proksi. Za ostale mreze linije za proksi treba da budu pod komentarom
//curl_setopt($curl, CURLOPT_PROXY, 'proxy.fon.rs:8080');
//kreiranje post parametara. Treba uneti odgovarajuce podatke. Ovde parametar src ucitava html fajl i prosledjuje ga
//veb servisu


$fields = array(
			'src' => urlencode($tekst),
			'username'	=> urlencode('luxybaxy'),
			'key'	=> urlencode('9fc8f13bbc25a92082390c00a0fa6ab3')
);

//konvertovanje niza u format pogodan za slanje POST zahteva
$fields_string="";
foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
//koristi se POST metoda
curl_setopt($curl,CURLOPT_POST, true);
//prosledjuju se prethodno pripremljeni post parametri
curl_setopt($curl,CURLOPT_POSTFIELDS, $fields_string);
//izvrsava se CURL zahtev
$curl_odgovor = curl_exec($curl);
//zatvara se CURL konekcija
curl_close($curl);
//ispisuje se PDF na ekranu, koji je dobijen kao odgovor na HTTP CURL zahtev
echo "header('Content-Type: application/pdf') ".$curl_odgovor;
?>
</body>
</html>