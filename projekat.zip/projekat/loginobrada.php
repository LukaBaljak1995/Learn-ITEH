<?php

include 'Database.php';
define('SALT', '!"#$%&/()=$%DFGBHJfghJ$%677$%');
if(isset($_POST["login-submit"])){
	

	$email = $_POST["email"];
	$password = SALT. md5($_POST["password"]);
	$db = new Database ("learn_iteh"); 
	 $sql = "SELECT * FROM Administrator WHERE email ='".$email."' AND sifra='".$password."'"; 
    $db->executeQuery($sql); 
    //da li postoji Admin sa tim mailom i passom?
    if($db->getRecords()==1){
      session_start();
      $red=$db->getResult()->fetch_object();
      $_SESSION["id"] = $email;
      $_SESSION["imeprezime"] = $red ->ime . " " . $red ->prezime;
      //ako postoji otvara pocetnu
      header('Location: adminpocetna.php');
    } else{
      //ako ne, trazi studenta sa mailom i passom
    $sql = "SELECT * FROM Student WHERE email ='".$email."' AND sifra='".$password."'"; 
    $db->executeQuery($sql); 

    if($db->getRecords()==1){
    	session_start();
      $red=$db->getResult()->fetch_object();
    	$_SESSION["id"] = $email;
      $_SESSION["imeprezime"] = $red ->ime . " " . $red ->prezime;
      //ako postoji, otvara mu pocetnu
		  header('Location: pocetna.php');
    } else {
      $_SESSION["login_pogresan"]="pogresan";
     header('Location: novi.php');
    }
}
}
if(isset($_POST["register-submit"])){
	$name = $_POST["name"];
	$surname = $_POST["surname"];
	$email = $_POST["email"];
	$password = SALT.md5($_POST["confirm-password"]);
	$db = new Database ("learn_iteh"); 
	$sql = "SELECT * FROM Student WHERE email ='".$email."' "; 
    $db->executeQuery($sql); 
   	//onda vec postoji u bazi
    if($db->getRecords()==1){

		header('Location: novi.php');

    } else {
		  $db->insert("Student", "Email, Ime, Prezime, Sifra, Uloga,DatumPridruzivanja", "'". $email."','".$name."','".$surname."','".$password."', 'student',Now()");
      //echo "'". $email."','".$name."','".$surname."','".$password."', 'student'";
      //echo "<br>";
   		$db->executeQuery($sql); 
   		session_start();
   		$_SESSION["id"]=$email;
      $_SESSION["imeprezime"]=$name." ".$surname;
    	header('Location: pocetna.php');
    }

}



?>