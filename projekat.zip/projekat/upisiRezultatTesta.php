<?php
session_start();
include 'Database.php';
$db = new Database("learn_iteh");

$rezultat = $_GET["rezultatTesta"];
$sql = "UPDATE STUDENT SET RezultatTesta = ". $rezultat ." WHERE EMAIL = '" .$_SESSION['id']."'";
echo $sql;
$db->executeQuery($sql);
?>