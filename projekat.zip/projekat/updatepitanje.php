<?php
if (isset($_POST['field']) && isset($_POST['value']) && isset($_POST['id'])){
	$polje = $_POST['field'];
	$vrednost = $_POST['value'];
	$id = $_POST['id'];
	
	include "Database.php";
	$db = new Database("learn_iteh");
	
	//$sql = "UPDATE pitanje SET ".$polje."='".$vrednost."' WHERE PitanjeID=".$id;
	//$db->executeQuery($sql);
	
	$stmt = $db->prepare("UPDATE pitanje SET ".$polje." = ? WHERE PitanjeID=".$id);
	
	if(gettype($polje)==string){
		$stmt->bind_param("s", $vrednost);
	}else{
		//u pitanju je integer
		$stmt->bind_param("i", $vrednost);
	}
	
	$stmt->execute();
	
	if (!$stmt) {
		echo "Greška pri izvođenju upita!";
	}else{
		if($stmt->affected_rows()==-1){
			printf("\nGreška: %s", $stmt->error);
		}
	}
}

?>