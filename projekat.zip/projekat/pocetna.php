<?php
include_once 'Database.php';
//header('Content-Type: application/pdf');
$db = new Database("learn_iteh");
session_start();
        if(isset($_SESSION["id"])){
          //echo $_SESSION["id"];
       } else {
          header("novi.php");
        }
$db->select("Student","DatumPridruzivanja",null,null,null,"Email = '".$_SESSION['id']."'");
$red = $db->getResult()->fetch_object();
$datumPridruzivanja=$red->DatumPridruzivanja;
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="pocetna_css.css">

    <title>Nauči iteh!</title>
     <link rel="icon" type="" href="img/elab-logo.png">
  </head>
  <body onload="funkcija()">
    

		<nav class="navbar navbar-expand-lg navbar-light bg-light ">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown" style="margin-left:  1100px;" >
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style=" color: black;">
            <?php echo $_SESSION["imeprezime"]; ?>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="pocetna.php?prikaz=o_igrici">O igrici</a>
          <a class="dropdown-item" href="novi.php">Odjavi se</a>
        </div>
      </li>
    </ul>
  </div>
</nav>



		<div class="sidenav" style="width: 175px">
  <a href="pocetna.php" style="margin-top: -20px">Početna</a>
  <a href="pocetna.php?prikaz=definicija" style="margin-top: 100px">Definicije</a>
  <a href="pocetna.php?prikaz=pitanje">Pitanja</a>
  <a href="pocetna.php?prikaz=poznate_definicije">Naučene definicije</a>
  <a href="pocetna.php?prikaz=zavrsni_test">Završni test</a>
</div>


<div class="container">
	 	<?php
	 	if(!isset($_GET['prikaz'])){
	 		include 'piechart.php';
	 	}
	 	?>
    <div class="row" style="margin-top: 50px; margin-left: 20px;">

    <div class="col" >
    	<?php
    		if(isset($_GET['prikaz'])){
                if($_GET['prikaz']=="sertifikat"){
                  
                    include ("pdfkonvertor.php");

                }

                 if($_GET['prikaz']=="o_igrici"){
                    ?>
                    <h4>Autori igrice:</h4>
                    <div class="card" style="width: 300px; display: inline-block;">
                      <img src="img/luka.jpg" alt="Luka" style="width:100%; height: 300px;">
                      <div class="container">
                        <h4><b>Luka Baljak</b></h4> 
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p> 
                      </div>
                    </div>
                    <div class="card" style="width: 300px; display: inline-block; margin-left: 100px;">
                      <img src="img/anja.jpg" alt="Anja" style="width:100%;height: 300px;">
                      <div class="container">
                        <h4><b>Anja Basara</b></h4> 
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p> 
                      </div>
                    </div>
                    <h4 style="margin-top: 20px">Pravila igrice:</h4>
                    <p>Na <i>početnoj strani</i> nalazi se statistika Vašeg dosadašnjeg učinka. </p>
                    <p>U <i>Definicijama</i> możete postepeno da prelazite nove deifnicije. </p>
                    <p>U <i>Pitanjima</i> możete da testirate svoje znanje nakon predjenih svih definicija odredjene oblasti. </p>
                    <p>U <i>Naučenim definicijama</i> możete obnoviti sve naučene definicije. </p>
                    <p>Nakon prelaska svih pitanja i definicija, omogućeno je polaganje <i>Završnog testa</i>!</p>
                    <?php
                 }
                if($_GET['prikaz']=="zavrsni_test"){
                    $sql = "SELECT COUNT(*) AS brojTacnoOdgovorenih FROM ODGOVOR WHERE EMAIL = '" .$_SESSION["id"]."' AND 
                    Ocena = 1";
                    $db->executeQuery($sql);
                    $red=$db->getResult()->fetch_object();
                    $brojTacnoOdgovorenih = $red->brojTacnoOdgovorenih;

                    $sql = "SELECT COUNT(*) AS ukupanBrojPitanja FROM Pitanje WHERE DatumPitanje<'".$datumPridruzivanja."'";
                    $db->executeQuery($sql);
                    $red=$db->getResult()->fetch_object();
                    $ukupanBrojPitanja=$red->ukupanBrojPitanja;
                    if($brojTacnoOdgovorenih!=$ukupanBrojPitanja){
                        ?>
                            <div id ="ispis" >
                                <div class="card">
                                      <div class="container">
                                         <h4><b id="oblast" style="margin-top: 10px;"> Još nije vreme za test!</b></h4> 
                                        <p id="tekst" style="margin-top: 30px">  </p> 
                                        

                                      </div>
                                    </div>
                            </div>
                        <?php
                    } else {
                        ?>
                        
                        

                        <div id="pocetakTesta">
                            <p>Ispunjeni su uslovi za polaganje završnog testa.</p>
                            <p>Ukoliko dođe do prekida internet konekcije prilikom rada, obratite se nekom od administratora.</p>
                            <p>Test je moguće polagati <b>neograničen broj puta</b>, ali se čuva samo rezultat poslednjeg polaganja!</p>
                            <button type="button"  class="btn btn-success" style="margin-top: 30px; margin-bottom: 15px; margin-left: 50px" 
                                onclick="zapocniTest()">Započni test!</button>
                        </div>
                        <div id="scoreDiv" style="visibility: hidden;"> 
                           
                            Rezultat je: <h2 id="score"></h2> 
                            Vaš sertifikat o poznavanju ITEHa koji je priznat u celom svetu možete preuzeti u PDF formatu! <br>
                            <a href="sertifikat.php"><button id="preuzmiPDF" class="btn btn-success" style="margin-top: 15px; margin-left: 275px">Preuzmite PDF!</button></a>
                        </div>

                        <div id ="ispisRezultata" style="visibility: hidden;margin-top: -100px;"> 
                        <?php
                        //vadjenje najveceg ID-a pitanja u bazi
                        $db->select("Pitanje","MAX(PitanjeID) as maxIndex",null,null,null);
                        $red=$db->getResult()->fetch_object();
                        $maxIndex = $red->maxIndex;
                        
                        //inicijalizacija niza u kom se cuvaju indexi postavljenih pitanja!
                        $niz_indexa = array();
                        $i_niz = 0;
                        while(count($niz_indexa)<($ukupanBrojPitanja/2)){
                            $random = rand(1, $maxIndex);
                            if(in_array($random, $niz_indexa)){
                                continue;
                            }
                            $db->select("Pitanje","*", null,null,null,"PitanjeID = " . $random." AND DatumPitanje<'".$datumPridruzivanja."'");
                            if($db->getRecords()==0)
                                continue;
                            $niz_indexa[$i_niz]=$random;
                            $i_niz++;
                            $red=$db->getResult()->fetch_object();
                            ?>
                                
                            <div class="card">
                                  <div class="container" id="<?php echo $red->PitanjeID; ?>">
                                    <p id="tekst" style="margin-top: 20px"> <?php echo ($i_niz). ". ". $red->TekstPitanja; ?></p> 
                                    <form id="<?php echo $red->PitanjeID; ?>">
                                    <?php
                                    $PonudjeniOdgovori = explode("@", $red->PonudjeniOdgovori);
                                        foreach($PonudjeniOdgovori as $kljuc => $vrednost){
                                        ?>
                                        
                                        <input id="<?php echo $red->PitanjeID; ?>" type="radio" name="<?php echo $red->PitanjeID; ?>" value="<?php echo $vrednost; ?>" onchange="proveriZavrsni(<?php echo $red->PitanjeID;?>)" style="margin-top: 30px;" >
                                        <?php echo $vrednost ; ?>
                                        
                                    <br>
                                    <?php
                                    }
                                    ?>
                                    </form>
                                   
                                    <div id="odgovorVezba" > </div>
                                    <div id="tacnoNetacno" style="text-align: center; "> </div>


                                  </div>
                                </div>
                       

                            <?php
                        }
                        ?>
                        </div>
                         <button id="predajButton" type="button"  class="btn btn-success" style="margin-top: 30px; margin-bottom: 15px; margin-left: 50px; visibility: hidden;" 
                                onclick="ispisiRezultateTesta()">Predaj test!</button>
                        <?php

                    }

                }

                if($_GET['prikaz']=="poznate_definicije"){

                    $url = 'localhost:8383/api/tipovidefinicije.json';
                    $curl = curl_init($url);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($curl, CURLOPT_POST, false);
                    $curl_odgovor = curl_exec($curl);
                    curl_close($curl);
                    $parsiran_json = json_decode ($curl_odgovor,true);
                    $i=0;
                     ?>
                     Odaberite oblast:     
                        <select class="custom-select" id="tipDefinicijeSelect" style="width: 500px" onchange="popuni()">
                            <?php
                                while ($i<6) {

                            ?>
                                    <option value="<?php echo $parsiran_json[$i]["TipDefinicijeID"] ?>"> 
                                        <?php echo $parsiran_json[$i]["Naziv"] ?>
                                            
                                        </option>
                            <?php
                                    $i++;
                                }
                            ?>
                        </select>
                        <div id="novispis" style="margin-top: 50px;"></div>
                    <?php
                }

    			if($_GET['prikaz']=="definicija"){
    				
    				$sql = "SELECT DefinicijaID FROM Student JOIN PoznavanjeDefinicije ON Student.Email = PoznavanjeDefinicije.Email
    				WHERE Student.Email='".$_SESSION["id"]."'";

    				$db->executeQuery($sql);
    				//DA LI JE PROCITAO NEKU DEFINICIJU?
    				if($db->getRecords()==0){
    					//AKO NIJE, ISPISUJE MU SE PRVA
    					
    					$sql = "SELECT COUNT(*) AS ukupnoPoTipu FROM DEFINICIJA WHERE TipDefinicijeID=1 AND DatumDefinicija<'".$datumPridruzivanja."'";
    					$db->executeQuery($sql);
    					$ukupnoPoTipu=$db->getResult()->fetch_object()->ukupnoPoTipu;

    					$db->select("Definicija","TekstDefinicije, Naziv", "TipDefinicije","TipDefinicijeID","TipDefinicijeID", "DefinicijaID=1");
    					
    					$red = $db->getResult()->fetch_object();
    					?>
    					<div id ="ispis" >
				    		<div class="card">
								  <div class="container">
								  	<p align="right" style = "margin-bottom: 2px;"><small> <?php echo "1/".$ukupnoPoTipu; ?> </small></p>
								    <h4><b id="oblast" style="margin-top: 10px;"> <?php echo $red->Naziv  ?></b></h4> 
								    <p id="tekst" style="margin-top: 40px"> <?php echo $red->TekstDefinicije ?></p> 
								    <a href="pocetna.php?prikaz=definicija"><button type="button"  class="btn btn-success" style="float: right;margin-top: 30px; margin-bottom: 15px;">Next</button></a>

								  </div>
								</div>
				    	</div>
    				<?php
    				$db->insert("PoznavanjeDefinicije", "Email, DefinicijaID", "'".$_SESSION["id"]."', 1");
    				} else {
    					//AKO JE NAUCIO NEKU, IDEMO DALJE
    					//Da li je poslednja definicija???
    					$sql = "SELECT count(*) AS brojPoznatih FROM `PoznavanjeDefinicije` WHERE Email='".$_SESSION["id"]."'";
    					$db->executeQuery($sql);
    					$red = $db->getResult()->fetch_object();
    					 $brojPoznatih = $red->brojPoznatih;


    					$sql = "SELECT count(*) AS ukupanBroj FROM Definicija WHERE DatumDefinicija<'".$datumPridruzivanja."'";
    					$db->executeQuery($sql);
    					$red = $db->getResult()->fetch_object();
    					$ukupanBroj = $red->ukupanBroj;
    					//DA LI JE PRESAO SVE DEFINICIJE?
    					if($ukupanBroj==$brojPoznatih){
    						//AKO JESTE CESTITKE
    						?>
	    					<div id ="ispis" >
					    		<div class="card">
									  <div class="container">
									     <h4><b id="oblast" style="margin-top: 10px;"> Čestitamo!</b></h4> 
									    <p id="tekst" style="margin-top: 30px"> Presli ste sve definicije! </p> 
									    

									  </div>
									</div>
					    	</div>
    				<?php
    					} else {
    						//AKO NIJE, IDEMO DALJE
    					//vadjenje  ID-a OBLASTI poslednje koju je naucio
    					$db->select("PoznavanjeDefinicije", "MAX(Definicija.TipDefinicijeID) AS TipDefinicijeID","Definicija","DefinicijaID","DefinicijaID"," PoznavanjeDefinicije.Email = '".$_SESSION["id"]."'",null,null);

    					$red = $db->getResult()->fetch_object();
    					$poslednjaTip = $red->TipDefinicijeID;
    					//vadjenje ID-a poslednje koju je naucio
    					$db->select("PoznavanjeDefinicije", "PoznavanjeDefinicije.DefinicijaID","Definicija","DefinicijaID","DefinicijaID"," PoznavanjeDefinicije.Email = '".$_SESSION["id"]."' AND Definicija.TipDefinicijeID= ".$poslednjaTip," Definicija.DefinicijaID DESC",1);

    					$red = $db->getResult()->fetch_object();
    					$poslednja = $red->DefinicijaID;

    					//Da li ima jos definicija u toj oblasti????
    					$db->select("Definicija", "DefinicijaID, TipDefinicijeID",null,null,null,"DefinicijaID > " . ($poslednja) . " and TipDefinicijeID = " .$poslednjaTip . " AND Definicija.DatumDefinicija<'".$datumPridruzivanja."'",null,null);

    					//da li je poslednja DEF KOJU JE NAUCIO ZAPRAVO POSLEDNJA u oblasti?
    					if($db->getRecords()==0){
    						//AKO JESTE, GLEDAMO DA LI JE ODG TACNO NA SVA PITANJA
    						//racunanje ukupnog broja TACNO odgovorenih pitanja od strane studenta
    						$sql = "SELECT COUNT(*) as brojTacnoOdgovorenih FROM Definicija JOIN Pitanje on Definicija.DefinicijaID = Pitanje.DefinicijaID JOIN Odgovor ON Pitanje.PitanjeID=Odgovor.PitanjeID where Odgovor.Email='".$_SESSION["id"]."' AND Odgovor.Ocena=1 AND Definicija.TipDefinicijeID= ".$poslednjaTip;
    						$db->executeQuery($sql);
    						$red = $db->getResult()->fetch_object();
    						$brojTacnoOdgovorenih = $red->brojTacnoOdgovorenih;

    						//racunanje ukupnog broja pitanja za datu oblast
    						$sql = "SELECT COUNT(*) as ukupanBrojPitanja FROM Definicija JOIN Pitanje on Definicija.DefinicijaID = Pitanje.DefinicijaID where Definicija.TipDefinicijeID= ".$poslednjaTip." AND DatumPitanje < '".$datumPridruzivanja."'";
    						$db->executeQuery($sql);
    						$red = $db->getResult()->fetch_object();
    						$ukupanBrojPitanja = $red->ukupanBrojPitanja;


    						if($brojTacnoOdgovorenih==$ukupanBrojPitanja){
    							//AKO JE TACNO ODG, PRIKAZI PRVU DEF SLEDECE OBLASTI
    							//$db->select("Definicija","DefinicijaID",null,null,null, "TipDefinicijeID = " . ($poslednjaTip+1),null,1);

    							$db->select("Definicija", "DefinicijaID, TipDefinicije.Naziv, Definicija.TekstDefinicije,  Definicija.TekstDefinicije ,TipDefinicije.TipDefinicijeID","TipDefinicije","TipDefinicijeID","TipDefinicijeID"," TipDefinicije.TipDefinicijeID=" .($poslednjaTip+1) ." AND DatumDefinicija< '".$datumPridruzivanja."'"," DefinicijaID ASC",1);
    							$red = $db->getResult()->fetch_object();

    							$sledeca = $red->DefinicijaID;
    							echo $sledeca ."<br>";
    							$sledecaTekst = $red->TekstDefinicije;
    							$sledecaTip=$red->TipDefinicijeID;
    							$sledecaTipNaziv = $red->Naziv;

    							//racunanje broja definicija odredjenog tipa
			    				$sql = "SELECT COUNT(*) AS ukupnoPoTipu FROM Definicija WHERE TipDefinicijeID=".$sledecaTip." 
                                 AND DatumDefinicija<'".$datumPridruzivanja."'";
			    				
			    				$db->executeQuery($sql);
			    				$count = $db->getResult()->fetch_object();
			    				$ukupnoPoTipu=$count->ukupnoPoTipu;

			    				//racunanje koliko definicija tog tipa zna student
			    				$sql = "SELECT count(*) AS brojPoznatihPoTipu FROM PoznavanjeDefinicije JOIN Definicija ON PoznavanjeDefinicije.DefinicijaID=Definicija.DefinicijaID WHERE Definicija.TipDefinicijeID=".$sledecaTip.
			    				" AND PoznavanjeDefinicije.Email='".$_SESSION["id"]."'";
			    				
			    				$db->executeQuery($sql);
			    				$count = $db->getResult()->fetch_object();
			    				$brojPoznatihPoTipu=$count->brojPoznatihPoTipu;
?>
    					<div id ="ispis" >
				    		<div class="card">
								  <div class="container">
								  	<p align="right" style = "margin-bottom: 2px;"><small> <?php echo ($brojPoznatihPoTipu+1)."/".$ukupnoPoTipu; ?> </small></p>
								    <h4><b id="oblast" style="margin-top: 10px;"> <?php echo $sledecaTipNaziv;  ?></b></h4> 
								    <p id="tekst" style="margin-top: 40px"> <?php echo $sledecaTekst; ?></p> 
								    <a href="pocetna.php?prikaz=definicija"><button type="button"  class="btn btn-success" style="float: right;margin-top: 30px; margin-bottom: 15px;">Next</button></a>


								  </div>
								</div>
				    	</div>
    				<?php
    				//echo $sledeca."<br>";
    				$db->insert("PoznavanjeDefinicije", "Email, DefinicijaID", "'".$_SESSION["id"]."'," . $sledeca);
    						} else {
					//AKO NIJE RECI MU DA PRVO MORA DA ODG TACNO NA SVA PITANJA DA BI PRESAO NA SLEDECU OBLAT
    						?>
    					<div id ="ispis" >
				    		<div class="card">
								  <div class="container">
								    
								    <p id="tekst" style="margin-top: 30px"> Da biste presli na sledecu oblast, prvo morate da odgovorite tacno na sva pitanja iz prethodne u sekciji Pitanja! Srecno! </p> 
								    

								  </div>
								</div>
				    	</div>
    				<?php
    			 }
    			} else {
    				//ISPISIVANJE SLEDECE DEFINICIJE!
    				//racunanje broja definicija odredjenog tipa
    				$sql = "SELECT COUNT(*) AS ukupnoPoTipu FROM Definicija WHERE TipDefinicijeID=".$poslednjaTip." and DatumDefinicija <'".$datumPridruzivanja."'";
    				$db->executeQuery($sql);
    				$count = $db->getResult()->fetch_object();
    				$ukupnoPoTipu=$count->ukupnoPoTipu;

    				//racunanje koliko definicija tog tipa zna student
    				$sql = "SELECT count(*) AS brojPoznatihPoTipu FROM PoznavanjeDefinicije JOIN Definicija ON PoznavanjeDefinicije.DefinicijaID=Definicija.DefinicijaID WHERE Definicija.TipDefinicijeID=".$poslednjaTip. " AND PoznavanjeDefinicije.Email = '" .$_SESSION["id"]."'";
    				
    				$db->executeQuery($sql);
    				$count = $db->getResult()->fetch_object();
    				$brojPoznatihPoTipu=$count->brojPoznatihPoTipu;

					$db->select("Definicija", "DefinicijaID, TekstDefinicije, Naziv","TipDefinicije","TipDefinicijeID","TipDefinicijeID","DefinicijaID > " . ($poslednja) . " and TipDefinicije.TipDefinicijeID = " .$poslednjaTip,null,null);
					$red = $db->getResult()->fetch_object();

					$nova = $red->DefinicijaID;

    				?>
    					<div id ="ispis" >
				    		<div class="card">
								  <div class="container">
								  	<p align="right" style = "margin-bottom: 2px;"><small> <?php echo ($brojPoznatihPoTipu+1)."/".$ukupnoPoTipu; ?> </small></p>
								    <h4><b id="oblast" style="margin-top: 10px;"> <?php echo $red->Naziv  ?></b></h4> 
								    <p id="tekst" style="margin-top: 40px"> <?php echo $red->TekstDefinicije ?></p> 
								    <a href="pocetna.php?prikaz=definicija"><button type="button"  class="btn btn-success" style="float: right;margin-top: 30px; margin-bottom: 15px;">Next</button></a>


								  </div>
								</div>
				    	</div>
    				<?php
    				$db->insert("PoznavanjeDefinicije", "Email, DefinicijaID", "'".$_SESSION["id"]."'," . $nova);
    			}
    		}
    			}
    			}
    			if($_GET['prikaz']=="pitanje"){
    				//vadjenje  ID-a poslednje definicije koju je naucio
    				$db->select("PoznavanjeDefinicije", "DefinicijaID",null,null,null," Email = '".$_SESSION["id"]."' "," DefinicijaID DESC",1);
    				$red = $db->getResult()->fetch_object();
    				$poslednja = $red->DefinicijaID;
					//vadjenje  ID-a OBLASTI poslednje koju je naucio
    				$db->select("Definicija", "TipDefinicijeID",null,null,null," DefinicijaID = " .$poslednja,null,null);
    					$red = $db->getResult()->fetch_object();
    					$poslednjaTip = $red->TipDefinicijeID;
					
					$db->select("TipDefinicije", "Naziv",null,null,null," TipDefinicijeID = " .$poslednjaTip,null,null);
    					$red = $db->getResult()->fetch_object();
    					$poslednjaTipNaziv=$red->Naziv;

    				//racunanje broja definicija odredjenog tipa
    				$sql = "SELECT COUNT(*) AS ukupnoPoTipu FROM Definicija WHERE TipDefinicijeID=".$poslednjaTip. " AND DatumDefinicija < '".$datumPridruzivanja."'";
    				$db->executeQuery($sql);
    				$count = $db->getResult()->fetch_object();
    				$ukupnoPoTipu=$count->ukupnoPoTipu;
    				//racunanje koliko definicija tog tipa zna student
    				$sql = "SELECT count(*) AS brojPoznatihPoTipu FROM PoznavanjeDefinicije JOIN Definicija ON PoznavanjeDefinicije.DefinicijaID=Definicija.DefinicijaID WHERE Definicija.TipDefinicijeID=".$poslednjaTip ." AND PoznavanjeDefinicije.Email = '".$_SESSION["id"]."'";
    				
    				$db->executeQuery($sql);
    				$count = $db->getResult()->fetch_object();
    				$brojPoznatihPoTipu=$count->brojPoznatihPoTipu;

    				//DA LI JE PRESAO SVE DEFINICIJE???
    				if($brojPoznatihPoTipu!=$ukupnoPoTipu){
    					//AKO NIJE, ISPISUJEMO DA TREBA PRVO DA IH PROCITA DA BI PRESAO NA PITANJA!
    						?>
    					<div id ="ispis" >
				    		<div class="card">
								  <div class="container">
								    
								    <p id="tekst" style="margin-top: 30px"> Da biste presli na pitanja, prvo morate da predjete sve definicije iz odredjene oblasti u sekciji Definicije! </p> 
								    

								  </div>
								</div>
				    	</div>

					<?php
    				} else {
    					//AKO JESTE PROCITAO DEFINICIJE, GLEDAMO GDE JE STAO SA PITANJIMA!
    					//vadjenje broja tacno odgovorenih za ovu oblast
    					$sql = "SELECT COUNT(*) as brojTacnoOdgovorenih FROM Definicija JOIN Pitanje on Definicija.DefinicijaID = Pitanje.DefinicijaID JOIN Odgovor ON Pitanje.PitanjeID=Odgovor.PitanjeID where Odgovor.Email='".$_SESSION["id"]."' AND Odgovor.Ocena=1 AND Definicija.TipDefinicijeID= ".$poslednjaTip;
    						$db->executeQuery($sql);
    						$red = $db->getResult()->fetch_object();
    						$brojTacnoOdgovorenih = $red->brojTacnoOdgovorenih;

    						//racunanje ukupnog broja pitanja za datu oblast
    						$sql = "SELECT COUNT(*) as ukupanBrojPitanja FROM Definicija JOIN Pitanje on Definicija.DefinicijaID = Pitanje.DefinicijaID where Definicija.TipDefinicijeID= ".$poslednjaTip." AND DatumPitanje<'".$datumPridruzivanja."'";
    						$db->executeQuery($sql);
    						$red = $db->getResult()->fetch_object();
    						$ukupanBrojPitanja = $red->ukupanBrojPitanja;
    						//TESTIRAMO JERY ODGOVORIO TACNO NA SVA PITANJA
						if($brojTacnoOdgovorenih==$ukupanBrojPitanja){
							//AKO JESTE, CESTITAMO MU I PREUSMERAVAMO GA NA CITANJE DEFINICIJA IZ SLEDECE OBLASTI!
							?>

		    					<div id ="ispis" >
						    		<div class="card">
										  <div class="container">
										  	
										    <h4><b id="oblast" style="margin-top: 10px;"> Čestitamo!</b></h4> 
										    <p id="tekst" style="margin-top: 40px"> Odgovorili ste tacno na sva pitanja iz oblasti <i><?php echo $poslednjaTipNaziv ?></i>! Sada mozete preci na citanje definicija iz sledece oblasti u sekciji Definicije!</p> 


										  </div>
										</div>
						    	</div>
		    				<?php
							
						} else {

						//AKO NIJE, GLEDAMO NA KOLIKO NJIH JE ODGOVORIO 
						//vadjenje broja odgovorenih za ovu oblast
    					$sql = "SELECT COUNT(*) as brojOdgovorenih FROM Definicija JOIN Pitanje on Definicija.DefinicijaID = Pitanje.DefinicijaID JOIN Odgovor ON Pitanje.PitanjeID=Odgovor.PitanjeID where Odgovor.Email='".$_SESSION["id"]."' AND Definicija.TipDefinicijeID= ".$poslednjaTip;
    						$db->executeQuery($sql);
    						$red = $db->getResult()->fetch_object();
    						$brojOdgovorenih = $red->brojOdgovorenih;

    						//racunanje ukupnog broja pitanja za datu oblast
    						$sql = "SELECT COUNT(*) as ukupanBrojPitanja FROM Definicija JOIN Pitanje on Definicija.DefinicijaID = Pitanje.DefinicijaID where Definicija.TipDefinicijeID= ".$poslednjaTip." AND DatumPitanje<'".$datumPridruzivanja."'";
    						$db->executeQuery($sql);
    						$red = $db->getResult()->fetch_object();
    						$ukupanBrojPitanja = $red->ukupanBrojPitanja;
    						//POREDIMO BROJ ODGOVORENIH I BROJ PITANJA IZ OBLASTI
    						if($brojOdgovorenih==$ukupanBrojPitanja){
    							//AKO JE NA SVA ODGOVORIO, IZVLACIMO REDOM ONE NA KOJE JE NETACNO ODGOVORIO
    							$sql = "SELECT Pitanje.TekstPitanja, Pitanje.PitanjeID, Pitanje.PonudjeniOdgovori FROM Definicija JOIN Pitanje on Definicija.DefinicijaID = Pitanje.DefinicijaID JOIN Odgovor ON Pitanje.PitanjeID=Odgovor.PitanjeID where Odgovor.Email='".$_SESSION["id"]."' AND Odgovor.Ocena=0 AND Definicija.TipDefinicijeID= ".$poslednjaTip ." ORDER BY PitanjeID ASC";

    							$db->executeQuery($sql);
    							$red = $db->getResult()->fetch_object();

    							?>
    					<div id ="ispis" >
				    		<div class="card">
								  <div class="container">
								  	
								   <h4><b id="oblast" style="margin-top: 10px;"> <?php echo $poslednjaTipNaziv;  ?></b></h4> 
								    <p id="tekst" style="margin-top: 40px"> <?php echo $red->TekstPitanja; ?></p> 
								    <form action="" >
								    <?php
								    $PonudjeniOdgovori = explode("@", $red->PonudjeniOdgovori);
										foreach($PonudjeniOdgovori as $kljuc => $vrednost){
										?>
										<input type="radio" name="odgovor" value="<?php echo $vrednost; ?>" onchange="proveri()" style="margin-top: 30px;">
										<?php echo $vrednost ; ?>
								    <br>
								    <?php
									}
								    ?>
									</form>
                                    <br><br>
									<div id="pitanjeID" hidden> <?php echo $red->PitanjeID ?></div>
									<div id="odgovorVezba" > </div>
									<div id="tacnoNetacno" style="text-align: center; " > </div>
								    <a href="pocetna.php?prikaz=pitanje"  ><button type="button"  class="btn btn-success" style="float: right;margin-top: 30px; margin-bottom: 15px; display: none" id = "sledecePitanje">Next</button></a>


								  </div>
								</div>
				    	</div>
    				<?php

    						} else {
    							//AKO NIJE, VADIMO SLEDECE PITANJE IZ BAZE I POSTAVLJAMO GA!
    							//vadjenje poslednjeg pitanja


    							$sql = "SELECT MAX(Pitanje.PitanjeID) AS PitanjeID FROM Pitanje JOIN Definicija on Definicija.DefinicijaID = Pitanje.DefinicijaID 
                                 JOIN Odgovor ON Pitanje.PitanjeID=Odgovor.PitanjeID 
                                 WHERE Definicija.TipDefinicijeID= ".$poslednjaTip ." AND DatumPitanje <'".$datumPridruzivanja."' 
                                  AND Odgovor.Email='".$_SESSION['id']."'";
                                echo "<br>" . $sql;
								$db->executeQuery($sql);
								
                                if($db->getRecords()==0){
									
									$poslednjePitanje=0;
								} else {
	    							$red = $db->getResult()->fetch_object();
	    							$poslednjePitanje = $red->PitanjeID;
    							}
                                echo $poslednjePitanje;
                                if($poslednjePitanje==null){
                                    if($poslednjaTip==1){
                                         $poslednjePitanje=0;
                                    } else {
                                        $sql ="SELECT MIN(Pitanje.PitanjeID) AS prvoIzSledece FROM Pitanje JOIN Definicija ON Pitanje.DefinicijaID=Definicija.DefinicijaID WHERE Definicija.TipDefinicijeID=".$poslednjaTip;
                                        $db->executeQuery($sql);
                                       $red = $db->getResult()->fetch_object();
                                        $poslednjePitanje=$red->prvoIzSledece;
                                        $poslednjePitanje = $poslednjePitanje-1;
                                        echo "<br>".$poslednjePitanje;
                                    }
                                }
    							$sql = "SELECT PitanjeID, TekstPitanja, PonudjeniOdgovori FROM Pitanje WHERE PitanjeID>".$poslednjePitanje. 
    							 " AND DatumPitanje< '".$datumPridruzivanja."' ORDER BY PitanjeID ASC LIMIT 1";
    							$db->executeQuery($sql);
    							$red = $db->getResult()->fetch_object();



    				?>
    					<div id ="ispis" >
				    		<div class="card">
								  <div class="container">
								  	
								   <h4><b id="oblast" style="margin-top: 10px;"> <?php echo $poslednjaTipNaziv;  ?></b></h4> 
								    <p id="tekst" style="margin-top: 40px"> <?php echo $red->TekstPitanja; ?></p> 
								    <form action="" >
								    <?php
								    $PonudjeniOdgovori = explode("@", $red->PonudjeniOdgovori);
										foreach($PonudjeniOdgovori as $kljuc => $vrednost){
										?>
										<input type="radio" name="odgovor" value="<?php echo $vrednost; ?>" onchange="proveri()" style="margin-top: 30px;">
										<?php echo $vrednost ; ?>
								    <br>
								    <?php
									}
								    ?>
									</form>
                                    <br><br>
									<div id="pitanjeID" hidden> <?php echo $red->PitanjeID ?></div>
									<div id="odgovorVezba" > </div>
									<div id="tacnoNetacno" style="text-align: center; "> </div>
								    <a href="pocetna.php?prikaz=pitanje"  ><button type="button"  class="btn btn-success" style="float: right;margin-top: 30px; margin-bottom: 15px; display: none" id = "sledecePitanje">Next</button></a>


								  </div>
								</div>
				    	</div>
    				<?php

    						}

						
    			}
			}
    				
    			}
    		}
    	?>
    
      
    </div>
    <div class="col-12 col-md-auto">
      
    </div>
    <div class="col col-lg-2">
      
    </div>
  </div>
</div>


    <!-- Optional JavaScript -->
    <script type="text/javascript">
        
        var tacniOdgovori = [];      
        var netacniOdgovori = [];     
        
        function preuzmiPDF(){
             var rezultat = document.getElementById('score').innerHTML;
            $.get("pdfkonvertor.php", { rezultat:rezultat},
                 function(data){
                  $(document.body).html(data);
             });
        }

        function zapocniTest(){
            
               // kojiPut++;
              tacniOdgovori = [];      
              netacniOdgovori = []; 
              document.getElementById("ispisRezultata").style.visibility = "visible";
              // $("#ispisRezultata").show();
                $("#pocetakTesta").attr('hidden','true');
                $("#predajButton").show();
                  document.getElementById("predajButton").style.visibility = "visible";
            
        }


        function proveriZavrsni( id){
            var odgovor = $("input[id="+id+"]:checked").attr('value');
            $.get("validacijaOdgovora.php", { zavrsni:1, pitanjeID:id, odgovor:odgovor },
                 function(data){
                    var tacno = parseInt(data);

                    if(tacno==1 && ($.inArray(id,tacniOdgovori)==-1)){
                        if($.inArray(id,netacniOdgovori)!=-1){
                            var index = netacniOdgovori.indexOf(id);
                            netacniOdgovori[index]=0;
                        }
                        tacniOdgovori.push(id);
                    } 
                    if(tacno==0 && ($.inArray(id,netacniOdgovori)==-1)){
                        if($.inArray(id,tacniOdgovori)!=-1){
                            var index =tacniOdgovori.indexOf(id);
                            tacniOdgovori[index]=0;
                        }
                         netacniOdgovori.push(id);
                    }
             });
        }

        function ispisiRezultateTesta(){
            document.getElementById("ispisRezultata").style.visibility = "hidden";
            document.getElementById("scoreDiv").style.visibility = "visible";
            $("#predajButton").hide();
            var brojTacnih=0, brojNetacnih=0;
            for ( i = 0; i<tacniOdgovori.length; i++) {
                if(tacniOdgovori[i]!=0){
                    brojTacnih+=1;
                }
            }
            for ( i = 0; i<netacniOdgovori.length; i++) {
                if(netacniOdgovori[i]!=0){
                    brojNetacnih+=1;
                }
            }

            alert("Broj tačnih: " + brojTacnih);

            alert("Broj netačnih: " + brojNetacnih);
            var rezultat = brojTacnih/(brojTacnih+brojNetacnih);
            alert(rezultat);
            var score = Math.round(rezultat*100);
            $("#score").html(score+"%");
            $.get("upisiRezultatTesta.php", { rezultatTesta: score});

        }

        function funkcija(){
             $.get("poznate_definicije.php", { tipDefinicije: 1},
                 function(data){
                  $('#novispis').html(data);
             });
        }

    	function popuni(){
            var tip = document.getElementById("tipDefinicijeSelect").value;
            $.get("poznate_definicije.php", { tipDefinicije: tip},
                 function(data){
                  $('#novispis').html(data);
             });
        }

    	function proveri(){
    		var odgovor = $("input[name='odgovor']:checked").val();
    		var pitanjeID = document.getElementById('pitanjeID').innerHTML;
    		
    		$("#sledecePitanje").show();
    		var tacno;
    		$.get("validacijaOdgovora.php", { zavrsni:0, pitanjeID:pitanjeID.trim(), odgovor:odgovor.trim() },
        		 function(data){
        		 	//$('#tacnoNetacno').html(data);
        		 	tacno = parseInt(data);
        		 	if(tacno==1){
                       // $('#tacnoNetacno').html("Odgovor je tacan!");
                     //   document.getElementById("tacnoNetacno").style.color="green";
                    } else {
                       //  $('#tacnoNetacno').html("Odgovor nije tacan!");
                        // document.getElementById("tacnoNetacno").style.color="red";
                    }
         	 });
    		if(tacno==1){
    			$("input[name='odgovor']:checked").style.background="#80ffd4";
    		} else {
				$("input[name='odgovor']:checked").style.background="#80ffd4";
    		}

    	}
    </script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script type="text/javascript" src="jquery-1.10.2.js"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>