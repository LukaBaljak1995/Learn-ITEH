<?php
if (isset($_POST['id'])){
	$id = $_POST['id'];
	
	include "Database.php";
	$db = new Database("learn_iteh");
	
	//$sql = "DELETE FROM definicija WHERE DefinicijaID = " .$id;
	//$db->executeQuery($sql);
	
	$stmt = $db->prepare("DELETE FROM definicija WHERE DefinicijaID = ?");
	$stmt->bind_param("i", $id);
	$stmt->execute();
	
	if (!$stmt) {
		echo "Greška pri izvođenju upita!";
	}else{
		if($stmt->affected_rows()==-1){
			printf("\nGreška: %s", $stmt->error);
		}
	}
}

?>
